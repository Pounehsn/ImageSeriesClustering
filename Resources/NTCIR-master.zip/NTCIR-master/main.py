import histsimilar as his

if __name__ == '__main__':
	print his.calc_similar_by_path('img/img1.jpg', 'img/img2.jpg')
